## Multi-Scale Vision Transformer with Normalized Total Gradient for 3D Medical Image Registration

### Introduction



### Setup
#### 1. Clone the repostory

#### 2. Environment

#### 3. Dataset

### Train & Evaluation



### Citation

### Acknowledgements
