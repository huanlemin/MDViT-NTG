# -*- coding:utf-8 -*-
# @FileName  :  ADNI.py
# @Time      :  2024/5/31 17:12
# @Author    :  Yuheng Fan

import numpy as np
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms as T
import random
import os
import torch
import glob
import nibabel as nib
import re
import utils

def nii2np(dir, normalize=True, shape=(256, 256, 256)):
    """
    Reading nii files to numpy array
    """
    nii_image = nib.load(dir)
    data = np.array(nii_image.get_fdata())
    if len(data.shape) == 4:
        data = data.squeeze(3)
    data_shape = data.shape
    for idx, each_dim in enumerate(data_shape):
        if each_dim > shape[idx]:
            excess = each_dim - shape[idx]
            trim_start = int(excess / 2)
            trim_end = trim_start + shape[idx]
            data = np.take(data, range(trim_start, trim_end), axis=idx)
        elif each_dim < shape[idx]:
            pad_pattern = [(0,0),(0,0),(0,0)]
            change_dim = int((shape[idx] - data_shape[idx]) / 2), shape[idx] - data_shape[idx] - int((shape[idx] - data_shape[idx]) / 2)
            pad_pattern[idx] = change_dim
            data = np.pad(data, pad_pattern, mode='constant', constant_values=0)
    # Normalize
    if normalize:
        data = (data - data.min()) / (data.max() - data.min())
    return data


def find_name(string):
    """
    match cases name
    :param string: path
    :return: 
    """
    return re.findall(r"(S_\d{4}-\d{4}-\d{2}-\d{2})", string)[-1]


class ADNI:
    """
    Get Data loaders for ADNI
    """

    def __init__(self, config):
        self.config = config
        assert hasattr(config.data, 'augmentation'), "ADNI need augmentation param"
        assert hasattr(config.data, 'mode'), "ADNI need mode param"
        assert hasattr(config.data, 'temp_dir'), "ADNI need temp_dir param"
        assert hasattr(config.data, 'shape'), "ADNI need shape param"
        self.data_shape = config.data.shape
        self.augmentation = config.data.augmentation
        self.mode = config.data.mode
        self.temp_dir = config.data.temp_dir

    def get_loaders(self, test_dir=None):
        """
        Generate Train/Eval and Test dataset
        """
        if test_dir == None:
            """ Loading train | eval Dataset during training """
            utils.logger.log_print("=> Loading ADNI Dataset...")
            train_dataset = ADNIDataset(dir=os.path.join(self.config.data.data_dir, 'train'),
                                        augmentation=self.augmentation,
                                        mode=self.mode,
                                        temp_dir=self.temp_dir,
                                        shape=self.data_shape)
            eval_dataset = ADNIDataset(dir=os.path.join(self.config.data.data_dir, 'test'),
                                       mode=self.mode,
                                       temp_dir=self.temp_dir,
                                       shape=self.data_shape)
            train_loader = DataLoader(train_dataset,
                                      batch_size=self.config.training.train_batch_size,
                                      shuffle=True,
                                      num_workers=self.config.data.num_workers,
                                      pin_memory=True)
            eval_loader = DataLoader(eval_dataset,
                                     batch_size=self.config.training.eval_batch_size,
                                     shuffle=False,
                                     num_workers=self.config.data.num_workers,
                                     pin_memory=True)
            return train_loader, eval_loader
        else:
            """ Loading testing sample """
            utils.logger.log_print(f"=> Loading Test samples from {str(test_dir)}...")
            assert os.path.exists(test_dir), f'Test sample dir:{test_dir} Not Exists!'
            test_dataset = ADNIDataset(dir=test_dir,
                                       mode=self.mode,
                                       temp_dir=self.temp_dir,
                                       shape=self.data_shape
                                       )
            test_loader = DataLoader(test_dataset,
                                     batch_size=self.config.training.eval_batch_size,
                                     shuffle=False,
                                     num_workers=self.config.data.num_workers,
                                     pin_memory=True)
            return test_loader


class ADNIDataset(torch.utils.data.Dataset):
    """
    Get torch Dataset for ADNI
    """

    def __init__(self, dir='', augmentation=False, mode='reference', temp_dir=None, shape=(256, 256, 256)):
        super().__init__()
        self.augmentation = augmentation
        self.mode = mode
        self.temp_dir = temp_dir
        self.data_shape = shape
        if 'train' in dir:
            input_files = glob.glob(os.path.join(dir, '*-t1.nii.gz'))
        elif 'test' in dir:
            input_files = glob.glob(os.path.join(dir, '*-t1.nii.gz'))
        elif 'val' in dir:
            input_files = glob.glob(os.path.join(dir, '*-t1.nii.gz'))
        else:
            raise ValueError('The dir of Input Dataset Not Support. (test/train/val)')
        assert len(input_files) != 0, f"Build file list not successful, pleace check glob.glob in {os.path.join(dir, '*-t1.nii.gz')}"
        self.input_files = input_files
        self.dataset_shape = len(input_files)

    def augmentation_methods(self, package):
        """ flip """
        flip_param = torch.rand(1)
        if flip_param > 0.5:
            flip_dim = random.randint(0, 2)
            package['fix']['data'] = torch.flip(package['fix']['data'], dims=[flip_dim])
            package['fix']['mask'] = torch.flip(package['fix']['mask'], dims=[flip_dim])
            package['move']['data'] = torch.flip(package['move']['data'], dims=[flip_dim])
            package['move']['mask'] = torch.flip(package['move']['mask'], dims=[flip_dim])
        """ rotation """
        rot_param = torch.rand(1)
        if rot_param > 0.5:
            angle = random.uniform(-30, 30)
            package['fix']['data'] = T.functional.rotate(package['fix']['data'], angle)
            package['fix']['mask'] = T.functional.rotate(package['fix']['mask'], angle)
            package['move']['data'] = T.functional.rotate(package['move']['data'], angle)
            package['move']['mask'] = T.functional.rotate(package['move']['mask'], angle)
        return package

    def __len__(self):
        return self.dataset_shape

    def __getitem__(self, index):
        name = self.input_files[index]
        """ Fixed Image """
        Fix_name = find_name(name)
        Fix_data = torch.tensor(nii2np(name, normalize=True, shape=self.data_shape))
        Fix_mask = (Fix_data > 0)
        """ Moving Image """
        if self.mode == "reference":
            name = self.input_files[random.choice([i for i in range(self.dataset_shape) if i != index])]
            Mov_name = find_name(name)
            Mov_data = torch.tensor(nii2np(name, normalize=True, shape=self.data_shape))
            Mov_mask = (Mov_data > 0)
            Mov_name = find_name(Mov_name)
        elif self.mode == "template":
            assert self.temp_dir != None, "ADNI Dataset is on template mode, but config.data.temp_dir is None"
            # change names when using new template
            Mov_name = 'Template'
            Mov_data_name = self.temp_dir + '/icbm_avg_152_t1_tal_nlin_symmetric_VI.nii'
            Mov_mask_name = self.temp_dir + '/icbm_avg_152_t1_tal_nlin_symmetric_VI_mask.nii'
            Mov_data = torch.tensor(nii2np(Mov_data_name, normalize=True, shape=self.data_shape))
            Mov_mask = torch.tensor(nii2np(Mov_mask_name, normalize=False, shape=self.data_shape))
            Mov_data = Mov_data * Mov_mask
            # change fix-move
            temp1, temp2, temp3 = Fix_data, Fix_mask, Fix_name
            Fix_data, Fix_mask, Fix_name = Mov_data, Mov_mask, Mov_name
            Mov_data, Mov_mask, Mov_name = temp1, temp2, temp3
        else:
            raise RuntimeError(f"ADNI Dataset receive a wrong mode:{self.mode}, support modes (reference/template)")

        """ Augmentation """
        package = {"fix": {"name": Fix_name, "data": Fix_data.float(), "mask": Fix_mask.float()},
                   "move": {"name": Mov_name, "data": Mov_data.float(), "mask": Mov_mask.float()}}
        if self.augmentation:
            package = self.augmentation_methods(package)
        return package