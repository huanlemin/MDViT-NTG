from datasets.LPBA import LPBA
from datasets.OASIS import OASIS
from datasets.ADNI import ADNI

__all__ = ["LPBA", "OASIS", "ADNI"]

