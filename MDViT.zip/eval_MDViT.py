import warnings
import argparse
import os
import time
import yaml
import torch
import numpy as np
import torch.nn.functional as F
import pandas as pd
from tqdm import tqdm

import datasets
import utils
import models


def get_sub_mask(mask, structure_idxs):
    mask = torch.round(mask).to(torch.float64)
    bi_value_mask = torch.zeros_like(mask).to(mask.device)
    for each_idx in structure_idxs:
        bi_value_mask += (mask == each_idx)
    bi_value_mask = (bi_value_mask != 0)
    return bi_value_mask


def get_sub_idxs(dataset, mode, seg_table):
    assert mode in ["template", "reference"], 'get_sub_idxs: mode must be template/reference, received {}'.format(mode)
    assert dataset in ["LPBA", "OASIS"], 'get_sub_idxs: dataset must be LPBA or OASIS, received {}'.format(dataset)

    if dataset == "LPBA":
        move_attr = "LPBAID"
    else:
        move_attr = "OASISID"
    move_idxs = [int(i) for i in list(seg_table[move_attr])[0].split('-')]

    if mode == "template":
        fix_attr = "MNI152ID"
    else:
        fix_attr = move_attr
    fix_idxs = [int(i) for i in list(seg_table[fix_attr])[0].split('-')]

    return fix_idxs, move_idxs


def parse_args_and_config():
    parser = argparse.ArgumentParser(description='Evaluating MDViT Model')
    parser.add_argument("--config", type=str, required=True,
                        help="Path to the config file")
    parser.add_argument('--resume', type=str, required=True,
                        help='Path for checkpoint to load and resume')
    parser.add_argument('--eval_mode', required=True, type=str,
                        help='Evaluation mode (whole/sub)')
    parser.add_argument("--image_folder", required=True, type=str,
                        help="Location to save evaluation result")
    parser.add_argument('--seed', default=124, type=int, metavar='N',
                        help='Seed for initializing training (default: 124)')
    parser.add_argument('--dataset', default="", type=str,
                        help='specific dataset')
    parser.add_argument('--mode', default='template', type=str, metavar='N', required=True,
                        help='registration mode(template/reference)')

    args = parser.parse_args()

    with open(os.path.join("configs", args.config), "r") as f:
        config = yaml.safe_load(f)
    new_config = utils.logger.dict2namespace(config)
    return args, new_config


def main():
    # initialize args and read config
    args, config = parse_args_and_config()

    # configs
    utils.logger.log_print("=> using config from: " + args.config)

    # adjust testing dataset
    config.data.dataset = args.dataset
    if args.dataset == 'OASIS':
        config.data.data_dir = '/root/autodl-tmp/data/OASIS3_414_dataset/'  # TODO: path to the OASIS dataset
    elif args.dataset == 'LPBA':
        config.data.data_dir = '/root/autodl-tmp/data/LPBA/'  # TODO: path to the LPBA dataset
    else:
        raise RuntimeError(f'receive an unknown dataset: {args.dataset}')

    # registration mode
    config.data.mode = args.mode
    if config.data.mode == "template":
        config.data.temp_dir = "/root/autodl-tmp/data/MNI152/"  # TODO: path to the template dataset
    elif config.data.mode == "reference":
        config.data.temp_dir = None
    else:
        raise RuntimeError(f"receive an unknown registration mode{args.mode}")

    # set random seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.benchmark = True

    # data loading
    utils.logger.log_print("=> using dataset '{}'".format(config.data.dataset))
    DATASET = datasets.__dict__[config.data.dataset](config)

    # matching model option
    utils.logger.log_print("=> creating model ...")
    valid_model_option = "MDViT"
    if config.model_option != valid_model_option:
        raise RuntimeError(f"Receive a unsupported option of model{config.model_option}. (valid: {valid_model_option})")
    else:
        model = models.MDViT_stage(img_size=config.data.shape[0], **utils.logger.namespace2dict(config.model))

    # build up evaluator
    utils.logger.log_print(f"=> Using model: {str(model.__class__)}")
    utils.logger.log_print("=> creating model evaluator...")
    evaluator = ModelEvaluator(model, DATASET, config, args)
    evaluator.evaluation()


class ModelEvaluator(object):
    def __init__(self, model, dataset, config, args):
        self.args = args
        self.config = config
        self.device = config.device

        """ dataset """
        self.dataset = dataset

        """ model """
        self.model = model
        self.model.to(self.device)
        self.affine_transform = models.AffineCOMTransform()
        self.affine_transform.to(self.device)
        self.init_center = models.Center_of_mass_initial_pairwise()
        self.init_center.to(self.device)

        # metric result
        self.df_samples = pd.DataFrame(columns=["name", "dice", "hd95", "jaccard", "time(/s)"])
        self.df_total = pd.DataFrame(columns=["name", "mean", "std"])

        # set saving dir
        if args.image_folder == "":
            project_dir = os.getcwd()
            saving_folder_name = time.strftime('%y%m%d-%H%M%S', time.localtime()) + "_" + config.data.dataset + '_eval_MDViT'
            saving_dir = os.path.join(project_dir, 'eval_result', saving_folder_name)
        else:
            project_dir = os.getcwd()
            saving_folder_name = args.image_folder
            saving_dir = os.path.join(project_dir, 'eval_result', saving_folder_name)

        if os.path.exists(saving_dir):
            warnings.warn(f"{saving_dir} already exist! Folders are at risk of being overwritten, The program will continue to run after 5 seconds")
            time.sleep(5.)
        else:
            os.mkdir(saving_dir)

        self.saving_dir = saving_dir
        utils.logger.log_print(f"saving dir: {self.saving_dir}")

    def load_ckpt(self, load_path):
        checkpoint = utils.logger.load_checkpoint(load_path, None)
        self.model.load_state_dict(utils.logger.remove_module_prefix(checkpoint['state_dict']), strict=True)
        utils.logger.log_print("=> loaded checkpoint '{}'".format(load_path))

    def evaluation(self):
        self.model.eval()

        """ load ckpt """
        print(self.args.resume)
        if os.path.isfile(self.args.resume):
            self.load_ckpt(self.args.resume)

        """ loading test loader"""
        if self.args.eval_mode == "whole":
            _, eval_loader = self.dataset.get_loaders()
        elif self.args.eval_mode == "sub":
            _, eval_loader = self.dataset.get_loaders(sub_seg=True)
        else:
            raise RuntimeError(f"Evaluation mode {self.args.eval_mode} not supported, supported modes: whole, sub")
        utils.logger.log_print(f"=> Test Samples: {str(eval_loader.__len__())}")

        if self.args.eval_mode == "whole":

            """ init metric """
            all_dice = []
            all_hd95 = []
            all_jac = []
            all_time = []
            all_name = []
            pbar = tqdm(total=eval_loader.__len__())

            """ start evaluation """
            utils.logger.log_print(f"=> Evaluation mode:{self.args.eval_mode}")
            for idx, data in enumerate(eval_loader):
                with torch.no_grad():
                    fix_data = data['fix']['data'].to(self.device).unsqueeze(dim=1)
                    fix_mask = data['fix']['mask'].to(self.device).unsqueeze(dim=1)
                    move_data = data['move']['data'].to(self.device).unsqueeze(dim=1)
                    move_mask = data['move']['mask'].to(self.device).unsqueeze(dim=1)
                    if self.config.data.com_initial:
                        #  center of mass initialization for mask
                        move_data, init_flow = self.init_center(move_data, fix_data)
                        move_mask = F.grid_sample(move_mask, init_flow, mode="bilinear", align_corners=True)

                    # undersample data
                    fix_data = F.interpolate(fix_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_data = F.interpolate(move_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    fix_mask = F.interpolate(fix_mask, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_mask = F.interpolate(move_mask, scale_factor=0.5, mode="trilinear", align_corners=True)
                    start_time = time.time()
                    warpped_x_list, y_list, affine_para_list = self.model(move_data, fix_data)
                    _, affine_matrix = self.affine_transform(move_mask, affine_para_list[-1])
                    warpped_grid = F.affine_grid(affine_matrix, move_mask.shape, align_corners=True)
                    warpped_move_mask = F.grid_sample(move_mask, warpped_grid, mode='bilinear', align_corners=True)
                    end_time = time.time()

                    """ metric """
                    """ whole brain mask evaluation """

                    # bivalue masks (since down-sample may induce float number)
                    bivalue_fix_mask = (fix_mask > 0).squeeze(dim=1)
                    bivalue_warpped_move_mask = (warpped_move_mask > 0).squeeze(dim=1)

                    # calculate metric
                    dice = utils.metrics.Dice(bivalue_fix_mask, bivalue_warpped_move_mask)
                    hd95 = utils.metrics.HD95(bivalue_fix_mask, bivalue_warpped_move_mask)
                    jac = utils.metrics.Jaccard(bivalue_fix_mask, bivalue_warpped_move_mask)
                    run_time = end_time - start_time

                    sample_name = data['fix']['name'][0] + '-' + data['move']['name'][0]
                    self.df_samples.loc[idx] = [sample_name, dice[0], hd95[0], jac[0], run_time]
                    all_dice.append(dice)
                    all_hd95.append(hd95)
                    all_jac.append(jac)
                    all_time.append(run_time)
                    all_name.append(sample_name)
                    # save image
                    utils.logger.save_image(fix_data[0][0], warpped_x_list[-1][0][0], os.path.join(self.saving_dir, 'fix_warpped_pair', sample_name + '.png'))
                pbar.update(1)
            """ evaluate metrics over samples """
            self.df_total.loc[1] = ['dice', np.mean(np.array(all_dice)), np.std(np.array(all_dice))]
            self.df_total.loc[2] = ['dice30', np.mean(np.array(sorted(all_dice)[:int(len(all_dice) * 0.3)])), np.std(np.array(sorted(all_dice)[:int(len(all_dice) * 0.3)]))]
            self.df_total.loc[3] = ['hd95', np.mean(np.array(all_hd95)), np.std(np.array(all_hd95))]
            self.df_total.loc[4] = ['jaccard', np.mean(np.array(all_jac)), np.std(np.array(all_jac))]
            self.df_total.loc[5] = ['time', np.mean(np.array(all_time)), np.std(np.array(all_time))]

            # save to excel
            with pd.ExcelWriter(
                    os.path.join(self.saving_dir, self.args.image_folder.split('/')[-1] + '_result.xlsx')) as writer:
                self.df_samples.to_excel(writer, sheet_name='cases', index=False)
                self.df_total.to_excel(writer, sheet_name='total', index=False)

        else:
            SegIndexTable = pd.read_csv('/root/autodl-tmp/data/SegLabel/seg.csv')  # TODO: path to the SegLabel

            all_seg = list(SegIndexTable["StructName"])

            self.df_samples = pd.DataFrame(columns=["name", "time", "whole"] + all_seg)
            self.df_total = pd.DataFrame(columns=["name", "mean", "std"])

            pbar = tqdm(total=eval_loader.__len__())
            """ start evaluation """
            utils.logger.log_print(f"=> Evaluation mode:{self.args.eval_mode}")
            for idx, data in enumerate(eval_loader):
                with torch.no_grad():
                    fix_data = data['fix']['data'].to(self.device).unsqueeze(dim=1)
                    fix_mask = data['fix']['mask'].to(self.device).unsqueeze(dim=1)
                    move_data = data['move']['data'].to(self.device).unsqueeze(dim=1)
                    move_mask = data['move']['mask'].to(self.device).unsqueeze(dim=1)

                    if self.config.data.com_initial:
                        #  center of mass initialization for mask
                        move_data, init_flow = self.init_center(move_data, fix_data)
                        move_mask = F.grid_sample(move_mask, init_flow, mode="bilinear", align_corners=True)

                    fix_data = F.interpolate(fix_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_data = F.interpolate(move_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    fix_mask = F.interpolate(fix_mask, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_mask = F.interpolate(move_mask, scale_factor=0.5, mode="trilinear", align_corners=True)
                    start_time = time.time()
                    warpped_x_list, y_list, affine_para_list = self.model(move_data, fix_data)
                    _, affine_matrix = self.affine_transform(move_mask, affine_para_list[-1])
                    warpped_grid = F.affine_grid(affine_matrix, move_mask.shape, align_corners=True)
                    warpped_move_mask = F.grid_sample(move_mask, warpped_grid, mode='bilinear', align_corners=True)
                    end_time = time.time()

                    sample_name = data['fix']['name'][0] + '-' + data['move']['name'][0]
                    whole_dice = utils.metrics.Dice((fix_mask > 0).squeeze(dim=1), (warpped_move_mask > 0).squeeze(dim=1))
                    run_time = end_time - start_time
                    sub_dices = []
                    for each_structure in all_seg:
                        fix_idxs, move_idxs = get_sub_idxs(mode=self.args.mode, dataset=self.args.dataset, seg_table=SegIndexTable[SegIndexTable['StructName'] == each_structure])
                        bivalue_fix_mask = get_sub_mask(fix_mask, structure_idxs=fix_idxs).squeeze(dim=1)
                        bivalue_warpped_move_mask = get_sub_mask(warpped_move_mask, structure_idxs=move_idxs).squeeze(dim=1)
                        sub_dice = utils.metrics.Dice(bivalue_fix_mask, bivalue_warpped_move_mask)
                        sub_dices.append(sub_dice[0])
                    all_dices = whole_dice + sub_dices
                    self.df_samples.loc[idx] = [sample_name, run_time] + all_dices

                    utils.logger.save_image(fix_data[0][0], warpped_x_list[-1][0][0], os.path.join(self.saving_dir, 'fix_warpped_pair', sample_name + '_x.png'))
                    utils.logger.save_image_y(fix_data[0][0], warpped_x_list[-1][0][0], os.path.join(self.saving_dir, 'fix_warpped_pair', sample_name + '_y.png'))
                    utils.logger.save_image_z(fix_data[0][0], warpped_x_list[-1][0][0], os.path.join(self.saving_dir, 'fix_warpped_pair', sample_name + '_z.png'))

                pbar.update(1)
            cal_colums = self.df_samples.columns[1:]
            mean_values = self.df_samples[cal_colums].mean()
            variance_values = self.df_samples[cal_colums].std()

            for idx, column in enumerate(cal_colums):
                mean = mean_values[column]
                variance = variance_values[column]
                self.df_total.loc[idx] = [column, mean, variance]

            # save to excel
            with pd.ExcelWriter(
                    os.path.join(self.saving_dir, self.args.image_folder.split('/')[-1] + '_result.xlsx')) as writer:
                self.df_samples.to_excel(writer, sheet_name='cases', index=False)
                self.df_total.to_excel(writer, sheet_name='total', index=False)
            utils.logger.log_print("=> End evaluation !")

            print(self.df_samples.head())
            print(self.df_total)


if __name__ == '__main__':
    main()
    utils.logger.log_print("=> End evaluation !")
