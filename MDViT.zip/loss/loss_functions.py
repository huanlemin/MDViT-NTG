# -*- coding:utf-8 -*-
# @FileName  :  loss_functions.py
# @Time      :  2024/5/15 12:59
# @Author    :  Yuheng Fan

import torch
import torch.nn as nn
import torch.nn.functional as F

class NCC(torch.nn.Module):
    """
    local (over window) normalized cross correlation
    This script is adapted from the follwing repository https://github.com/cwmok/C2FViT
    """

    def __init__(self, win=7, eps=1e-5):
        super(NCC, self).__init__()
        self.win = win
        self.eps = eps
        self.w_temp = win

    def forward(self, I, J):
        ndims = 3
        win_size_1d = self.w_temp

        # set window size
        if self.win is None:
            self.win = [5] * ndims
        else:
            self.win = [self.w_temp] * ndims

        weight_win_size = self.w_temp
        weight = torch.ones((1, 1, weight_win_size, weight_win_size, weight_win_size), device=I.device,
                            requires_grad=False)
        conv_fn = F.conv3d

        # compute CC squares
        I2 = I * I
        J2 = J * J
        IJ = I * J

        # compute filters
        # compute local sums via convolution
        I_sum = conv_fn(I, weight, padding=int(win_size_1d / 2))
        J_sum = conv_fn(J, weight, padding=int(win_size_1d / 2))
        I2_sum = conv_fn(I2, weight, padding=int(win_size_1d / 2))
        J2_sum = conv_fn(J2, weight, padding=int(win_size_1d / 2))
        IJ_sum = conv_fn(IJ, weight, padding=int(win_size_1d / 2))

        # compute cross correltorch.
        win_size = win_size_1d ** ndims
        u_I = I_sum / win_size
        u_J = J_sum / win_size

        cross = IJ_sum - u_J * I_sum - u_I * J_sum + u_I * u_J * win_size
        I_var = I2_sum - 2 * u_I * I_sum + u_I * u_I * win_size
        J_var = J2_sum - 2 * u_J * J_sum + u_J * u_J * win_size

        cc = cross * cross / (I_var * J_var + self.eps)

        # return negative cc.
        return -1.0 * torch.mean(cc)


class multi_resolution_NCC(torch.nn.Module):
    """
    local (over window) normalized cross correlation
    This script is adapted from the follwing repository https://github.com/cwmok/C2FViT
    """

    def __init__(self, win=None, eps=1e-5, scale=3, kernel=3):
        super(multi_resolution_NCC, self).__init__()
        self.num_scale = scale
        self.kernel = kernel
        self.similarity_metric = []

        for i in range(scale):
            self.similarity_metric.append(NCC(win=win - (i * 2)))

    def forward(self, I, J):
        total_NCC = []
        for i in range(self.num_scale):
            current_NCC = self.similarity_metric[i](I, J)
            total_NCC.append(current_NCC / (2 ** i))
            I = nn.functional.avg_pool3d(I, kernel_size=self.kernel, stride=2, padding=self.kernel // 2,
                                         count_include_pad=False)
            J = nn.functional.avg_pool3d(J, kernel_size=self.kernel, stride=2, padding=self.kernel // 2,
                                         count_include_pad=False)
        return sum(total_NCC)


class NTG(torch.nn.Module):
    def __init__(self, delta=1):
        super(NTG, self).__init__()
        """
        The representation of 3D Sobel Operator is adapted from:
        Ashraf, H., Mousa, W. A., & Al Dossary, S. (2016). Sobel filter for edge detection of hexagonally sampled 3D seismic data. Geophysics, 81(6), N41-N51.
        """
        self.eps = 1e-5
        self.delta = delta
        self.sobel_y = torch.tensor([
            [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]],
            [[-2, 0, 2], [-4, 0, 4], [-2, 0, 2]],
            [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]
        ]).view(1, 1, 3, 3, 3)
        self.sobel_x = torch.tensor([
            [[-1, -2, -1], [0, 0, 0], [1, 2, 1]],
            [[-2, -4, -2], [0, 0, 0], [2, 4, 2]],
            [[-1, -2, -1], [0, 0, 0], [1, 2, 1]]
        ], ).view(1, 1, 3, 3, 3)
        self.sobel_z = torch.tensor([
            [[-1, -2, -1], [-2, -4, -2], [-1, -2, -1]],
            [[0, 0, 0], [0, 0, 0], [0, 0, 0]],
            [[1, 2, 1], [2, 4, 2], [1, 2, 1]]
        ]).view(1, 1, 3, 3, 3)

    def sum_abs_nabda_l(self, input):
        """

        :param input: shape (B, C, z, y, x)
        :param delta: stride of diff
        :return:

        """
        grad_x = F.conv3d(input, self.sobel_x.to(input.dtype).to(input.device), stride=(self.delta, 1, 1))
        grad_y = F.conv3d(input, self.sobel_y.to(input.dtype).to(input.device), stride=(1, self.delta, 1))
        grad_z = F.conv3d(input, self.sobel_z.to(input.dtype).to(input.device), stride=(1, 1, self.delta))
        out = torch.norm(grad_x, p=1) + torch.norm(grad_y, p=1) + torch.norm(grad_z, p=1)
        return out

    def forward(self, pred, fix):
        """
        Calculate
        :param pred: warped image, shape (B,C, z, y, x)
        :param fix: fixed image, shape (B, C, z, y, x)
        :return:
        """
        ntg = self.sum_abs_nabda_l(pred - fix) / (self.sum_abs_nabda_l(pred) + self.sum_abs_nabda_l(fix) + self.eps)
        return ntg


class multi_resolution_NTG(torch.nn.Module):
    def __init__(self, scale=3, delta=5, kernel=5):
        super(multi_resolution_NTG, self).__init__()
        self.num_scale = scale
        self.kernel = kernel
        self.similarity_metric = [NTG(delta=delta) for i in range(scale)]

    def forward(self, pred, fix):
        total_NTG = []
        for i in range(self.num_scale):
            current_NTG = self.similarity_metric[i](pred, fix)
            total_NTG.append(current_NTG / (2 ** i))

            pred = nn.functional.avg_pool3d(pred, kernel_size=self.kernel, stride=2, padding=self.kernel // 2,
                                            count_include_pad=False)
            fix = nn.functional.avg_pool3d(fix, kernel_size=self.kernel, stride=2, padding=self.kernel // 2,
                                           count_include_pad=False)

        return sum(total_NTG)