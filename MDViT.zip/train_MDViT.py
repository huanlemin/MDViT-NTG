import re
import warnings
import argparse
import os
import time
import yaml
import torch
import torch.backends.cudnn as cudnn
import torch.utils.data
import numpy as np
from copy import deepcopy
import torch.nn.functional as F

import datasets
import utils
from loss import loss_functions
import models


def parse_args_and_config():
    # parser：记录训练信息
    parser = argparse.ArgumentParser(description='Training MDViT Model')
    parser.add_argument("--config", type=str, default='Regist_reference.yml',
                        help="Path to the config file")
    parser.add_argument('--resume', default='', type=str,
                        help='Path for checkpoint to load and resume')
    parser.add_argument("--image_folder", default='', type=str,
                        help="Location to save training result")
    parser.add_argument('--seed', default=124, type=int, metavar='N',
                        help='Seed for initializing training (default: 124)')
    parser.add_argument('--seed', default=124, type=int, metavar='N',
                        help='Seed for initializing training (default: 124)')
    args = parser.parse_args()

    with open(os.path.join("configs", args.config), "r") as f:
        config = yaml.safe_load(f)
    new_config = utils.logger.dict2namespace(config)
    return args, new_config


def main():
    # initialize args and read config
    args, config = parse_args_and_config()
    utils.logger.log_print("=> using config from: " + args.config)

    # set saving dir
    if args.image_folder == "":
        project_dir = os.getcwd()
        saving_folder_name = time.strftime('%y%m%d-%H%M%S',
                                           time.localtime()) + "_" + config.data.dataset + '_train_MDViT'
        saving_dir = os.path.join(project_dir, 'result', saving_folder_name)
    else:
        project_dir = os.getcwd()
        saving_folder_name = args.image_folder
        saving_dir = os.path.join(project_dir, 'result', saving_folder_name)
    config.project_dir = project_dir
    config.saving_dir = saving_dir
    config.saving_folder_name = saving_folder_name
    if os.path.exists(saving_dir):
        warnings.warn(
            f"{saving_dir} already exist! Folders are at risk of being overwritten, The program will continue to run after 5 seconds")
        time.sleep(5.)
    else:
        os.mkdir(saving_dir)  # create checkpoint saving dir

    # writing config into checkpoint dir
    with open(os.path.join(saving_dir, args.config), 'w', encoding='utf-8') as f:
        c = deepcopy(config)
        c = utils.logger.namespace2dict(c)  # namespace to dict
        yaml.dump(c, f, allow_unicode=True)

    # show device to run
    utils.logger.log_print("=> Using device: {}".format(config.device))

    # set random seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.benchmark = True

    # data loading
    utils.logger.log_print(f"=> Using registration mode: {config.data.mode}")
    utils.logger.log_print(f"=> Using dataset: {config.data.dataset}")
    DATASET = datasets.__dict__[config.data.dataset](config)

    # matching model option
    utils.logger.log_print("=> creating model ...")
    valid_model_option = "MDViT"
    if config.model_option != valid_model_option:
        raise RuntimeError(f"Receive a unsupported option of model{config.model_option}. (valid: {valid_model_option})")
    else:
        model = models.MDViT_stage(img_size=config.data.shape[0], **utils.logger.namespace2dict(config.model))
    utils.logger.log_print(f"=> Using model: {str(model.__class__)}")
    utils.logger.log_print("=> creating model trainer...")

    # training
    trainer = ModelTrainer(model, DATASET, config, args)
    trainer.train()


class ModelTrainer(object):
    def __init__(self, model, dataset, config, args):
        self.args = args
        self.config = config
        self.device = config.device

        """ dataset """
        self.dataset = dataset

        """ model """
        self.model = model
        self.model.to(self.device)
        self.affine_transform = models.AffineCOMTransform()
        self.affine_transform.to(self.device)
        self.init_center = models.Center_of_mass_initial_pairwise()
        self.init_center.to(self.device)

        """ loss """
        valid_losses = ['NTG', 'NCC']
        if not self.config.training.training_loss in valid_losses:
            raise RuntimeError(
                f"Wrong training loss setting! Support losses: {str(valid_losses)}, but get {self.config.training.training_loss} ")
        elif self.config.training.training_loss == 'NTG':
            self.loss_function = loss_functions.multi_resolution_NTG(delta=4, scale=3, kernel=5)
        else:
            self.loss_function = loss_functions.multi_resolution_NCC(win=7, scale=3)
        utils.logger.log_print("=> loss: " + str(self.loss_function))

        """ optimization """
        self.optimizer = utils.optimize.get_optimizer(config, model.parameters())
        self.optimizer_scheduler = utils.optimize.get_optimizer_scheduler(self.optimizer,
                                                                          step_size=config.optim.step_size,
                                                                          gamma=config.optim.gamma)

        """ eval info """
        self.start_epoch, self.step = 0, 0
        self.train_loss_info = []
        self.eval_loss_info = []
        self.train_dice_info = []
        self.train_dice30_info = []
        self.train_jaccard_info = []
        self.train_hd95_info = []
        self.eval_dice_info = []
        self.eval_dice30_info = []
        self.eval_jaccard_info = []
        self.eval_hd95_info = []

    def load_ckpt(self, load_path):
        checkpoint = utils.logger.load_checkpoint(load_path, None)
        self.start_epoch = checkpoint['epoch']
        self.step = checkpoint['step']
        self.model.load_state_dict(checkpoint['state_dict'], strict=True)
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        utils.logger.log_print(
            "=> loaded checkpoint '{}' (epoch {}, step {})".format(load_path, checkpoint['epoch'], checkpoint['step']))

    def freeze_param(self):
        change_pattern = [r"patch_embed_\d+_xy", r"stage_\d+\.0", r"head_\d+", r"stage_\d+\.\d+\.mlp", r"squeeze_\d+"]
        utils.logger.log_print(f"=> freeze model according to the change pattern: {str(change_pattern)}")
        for name, module in self.model.named_modules():
            change = True if (re.search("|".join(change_pattern), name) is not None) else False
            if change:
                for param in module.parameters():
                    param.requires_grad = True
            else:
                for param in module.parameters():
                    param.requires_grad = False

    def train(self):
        cudnn.benchmark = True

        """ load ckpt """
        if os.path.isfile(self.args.resume):
            self.load_ckpt(self.args.resume)
        scheduler = self.optimizer_scheduler

        """ load data loader """
        train_loader, eval_loader = self.dataset.get_loaders()
        utils.logger.log_print(f"=> Train Samples: {str(train_loader.__len__())}")
        utils.logger.log_print(f"=> Eval Samples: {str(eval_loader.__len__())}")

        """ train model """
        for epoch in range(self.start_epoch, self.config.training.n_epochs):
            utils.logger.log_print('epoch: ' + str(epoch))
            start_time = time.time()
            for idx, data in enumerate(train_loader):
                self.model.train()
                self.optimizer.zero_grad()
                """ freeze parameters during training """
                if self.config.training.freeze_param:
                    self.freeze_param()

                """ pick up fix/move data """
                fix_data = data['fix']['data'].to(self.device).unsqueeze(dim=1)
                move_data = data['move']['data'].to(self.device).unsqueeze(dim=1)

                """ COM initialization """
                if self.config.data.com_initial:
                    move_data, _ = self.init_center(move_data, fix_data)

                """ Down-sample fix/move data (for reasonable computing costs) """
                fix_data = F.interpolate(fix_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                move_data = F.interpolate(move_data, scale_factor=0.5, mode="trilinear", align_corners=True)

                """ Model output (pyramid list): warpped moving image, fixed image, affine param """
                warpped_x_list, y_list, affine_para_list = self.model(move_data, fix_data)

                """ calculate loss and update gradient """
                loss = self.loss_function(warpped_x_list[-1], y_list[-1])
                loss.backward()

                """ gradient clip """
                torch.nn.utils.clip_grad_value_(parameters=self.model.parameters(), clip_value=10.)

                self.optimizer.step()
                self.step += 1

                """
                logging
                """
                if self.step == 100:
                    """ show GPU memory usage """
                    utils.logger.log_print(
                        f"=> GPU Memory Usage : {utils.logger.hum_convert(torch.cuda.memory_reserved())}")

                if self.step % 10 == 0:
                    """ show training info """
                    utils.logger.log_print(
                        f"step: {self.step}, loss: {round(loss.item(), 4)}, time: {round(time.time() - start_time, 2)}s/10step")
                    start_time = time.time()

                if self.step % self.config.training.eval_loss_freq == 0:
                    """ calculate eval loss """
                    self.model.eval()
                    val_loss = self.eval_loss(eval_loader)
                    utils.logger.log_print(f"  step: {self.step}, eval loss: {round(val_loss, 4)}")
                    self.eval_loss_info.append([self.step, val_loss])

                if self.step % self.config.training.train_loss_freq == 0:
                    """ save train/eval loss fig """
                    self.train_loss_info.append([self.step, loss.item()])
                    utils.logger.save_loss(train_loss_info=np.array(self.train_loss_info),
                                           val_loss_info=np.array(self.eval_loss_info), filename=self.config.saving_dir,
                                           step=self.step)

                if self.step > 0 and self.step % self.config.training.eval_save_freq == 0:
                    """ evaluation on val dataset """
                    utils.logger.log_print(
                        f"Start Evaluation (evaluation batch number: {self.config.training.eval_batch_num})")
                    self.sample_evaluation(train_data=train_loader, eval_data=eval_loader)

                if self.step > 0 and self.step % self.config.training.snapshot_freq == 0:
                    """ save checkpoint """
                    utils.logger.save_checkpoint({
                        'epoch': epoch + 1,
                        'step': self.step,
                        'state_dict': self.model.state_dict(),
                        'optimizer': self.optimizer.state_dict(),
                        'params': self.args,
                        'config': self.config
                    }, filename=self.config.saving_dir)

            scheduler.step()

        utils.logger.log_print(
            "=> End trianing ! Total-(epoch {}, step {})".format(str(self.config.training.n_epochs), str(self.step)))

    def eval_loss(self, data_loader):
        val_losses = []
        self.model.eval()
        for idx, data in enumerate(data_loader):
            if idx < 5:  # only calculate first 5 cases
                fix_data = data['fix']['data'].to(self.device).unsqueeze(dim=1)
                move_data = data['move']['data'].to(self.device).unsqueeze(dim=1)
                if self.config.data.com_initial:
                    move_data, _ = self.init_center(move_data, fix_data)
                fix_data = F.interpolate(fix_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                move_data = F.interpolate(move_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                with torch.no_grad():
                    warpped_x_list, y_list, affine_para_list = self.model(move_data, fix_data)
                    loss = self.loss_function(warpped_x_list[-1], y_list[-1])
                val_losses.append(loss.item())
        return torch.tensor(val_losses).mean().item()

    def sample_evaluation(self, train_data, eval_data):
        self.model.eval()
        image_folder = os.path.join(self.config.saving_dir, self.config.data.dataset + "_" + str(self.step))
        start_time = time.time()

        """ eval on train """
        utils.logger.log_print(f'Evaluating on {self.config.training.eval_batch_num} batches of train dataset')
        all_dice = []
        all_hd95 = []
        all_jac = []
        for idx, data in enumerate(train_data):
            if idx < self.config.training.eval_batch_num:
                with torch.no_grad():
                    fix_data = data['fix']['data'].to(self.device).unsqueeze(dim=1)
                    fix_mask = data['fix']['mask'].to(self.device).unsqueeze(dim=1)
                    move_data = data['move']['data'].to(self.device).unsqueeze(dim=1)
                    move_mask = data['move']['mask'].to(self.device).unsqueeze(dim=1)
                    if self.config.data.com_initial:
                        #  center of mass initialization for mask
                        move_data, init_flow = self.init_center(move_data, fix_data)
                        move_mask = F.grid_sample(move_mask, init_flow, mode="bilinear", align_corners=True)

                    # undersample data
                    fix_data = F.interpolate(fix_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_data = F.interpolate(move_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    fix_mask = F.interpolate(fix_mask, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_mask = F.interpolate(move_mask, scale_factor=0.5, mode="trilinear", align_corners=True)

                    warpped_x_list, y_list, affine_para_list = self.model(move_data, fix_data)
                    _, affine_matrix = self.affine_transform(move_mask, affine_para_list[-1])
                    warpped_grid = F.affine_grid(affine_matrix, move_mask.shape, align_corners=True)
                    warpped_move_mask = F.grid_sample(move_mask, warpped_grid, mode='bilinear', align_corners=True)

                    # bivalue masks
                    bivalue_fix_mask = (fix_mask > 0).squeeze(dim=1)
                    bivalue_warpped_move_mask = (warpped_move_mask > 0).squeeze(dim=1)
                    all_dice.extend(utils.metrics.Dice(bivalue_fix_mask, bivalue_warpped_move_mask))
                    all_jac.extend(utils.metrics.Jaccard(bivalue_fix_mask, bivalue_warpped_move_mask))
                    all_hd95.extend(utils.metrics.HD95(bivalue_fix_mask, bivalue_warpped_move_mask))
                    for save_idx in range(int(fix_data.shape[0])):
                        file_name = data['fix']['name'][save_idx] + '-' + data['move']['name'][save_idx] + '.png'
                        utils.logger.save_image(fix_data[save_idx][0], warpped_x_list[-1][save_idx][0],
                                                file_directory=os.path.join(image_folder, 'train', file_name))
        train_dice = np.mean(np.array(all_dice))
        train_dice30 = np.mean(np.array(sorted(all_dice)[:int(len(all_dice) * 0.3)]))
        train_hd95 = np.mean(np.array(all_hd95))
        train_jac = np.mean(np.array(all_jac))
        utils.logger.log_print(
            f"Eval on train => dice:{train_dice:.4f} dice30: {train_dice30:.4f} HD95: {train_hd95:.4f} Jac: {train_jac:.4f}")
        self.train_dice_info.append([self.step, train_dice])
        self.train_dice30_info.append([self.step, train_dice30])
        self.train_hd95_info.append([self.step, train_hd95])
        self.train_jaccard_info.append([self.step, train_jac])
        utils.logger.save_dice_tr(np.array(self.train_dice_info), filename=self.config.saving_dir)
        utils.logger.save_dice30_tr(np.array(self.train_dice30_info), filename=self.config.saving_dir)
        utils.logger.save_hd95_tr(np.array(self.train_hd95_info), filename=self.config.saving_dir)
        utils.logger.save_jaccard_tr(np.array(self.train_jaccard_info), filename=self.config.saving_dir)

        """ eval on val  """
        utils.logger.log_print(f'Evaluating on {self.config.training.eval_batch_num} batches of val dataset')
        all_dice = []
        all_hd95 = []
        all_jac = []
        for idx, data in enumerate(eval_data):
            if idx < self.config.training.eval_batch_num:
                with torch.no_grad():
                    fix_data = data['fix']['data'].to(self.device).unsqueeze(dim=1)
                    fix_mask = data['fix']['mask'].to(self.device).unsqueeze(dim=1)
                    move_data = data['move']['data'].to(self.device).unsqueeze(dim=1)
                    move_mask = data['move']['mask'].to(self.device).unsqueeze(dim=1)
                    if self.config.data.com_initial:
                        # center of mass initialization for mask
                        move_data, init_flow = self.init_center(move_data, fix_data)
                        move_mask = F.grid_sample(move_mask, init_flow, mode="bilinear", align_corners=True)

                    # undersample data
                    fix_data = F.interpolate(fix_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_data = F.interpolate(move_data, scale_factor=0.5, mode="trilinear", align_corners=True)
                    fix_mask = F.interpolate(fix_mask, scale_factor=0.5, mode="trilinear", align_corners=True)
                    move_mask = F.interpolate(move_mask, scale_factor=0.5, mode="trilinear", align_corners=True)
                    warpped_x_list, y_list, affine_para_list = self.model(move_data, fix_data)
                    _, affine_matrix = self.affine_transform(move_mask, affine_para_list[-1])
                    warpped_grid = F.affine_grid(affine_matrix, move_mask.shape, align_corners=True)
                    warpped_move_mask = F.grid_sample(move_mask, warpped_grid, mode='bilinear', align_corners=True)

                    # bivalue masks
                    bivalue_fix_mask = (fix_mask > 0).squeeze(dim=1)
                    bivalue_warpped_move_mask = (warpped_move_mask > 0).squeeze(dim=1)
                    all_dice.extend(utils.metrics.Dice(bivalue_fix_mask, bivalue_warpped_move_mask))
                    all_jac.extend(utils.metrics.Jaccard(bivalue_fix_mask, bivalue_warpped_move_mask))
                    all_hd95.extend(utils.metrics.HD95(bivalue_fix_mask, bivalue_warpped_move_mask))

                    for save_idx in range(int(fix_data.shape[0])):
                        file_name = data['fix']['name'][save_idx] + '-' + data['move']['name'][save_idx] + '.png'
                        utils.logger.save_image(fix_data[save_idx][0], warpped_x_list[-1][save_idx][0],
                                                os.path.join(image_folder, 'val', file_name))

        eval_dice = np.mean(np.array(all_dice))
        eval_dice30 = np.mean(np.array(sorted(all_dice)[:int(len(all_dice) * 0.3)]))
        eval_hd95 = np.mean(np.array(all_hd95))
        eval_jac = np.mean(np.array(all_jac))
        end_time = time.time()
        utils.logger.log_print(
            f"Eval on val (time:{end_time - start_time:.4f})=> dice:{eval_dice:.4f} dice30: {eval_dice30:.4f} HD95: {eval_hd95:.4f} Jac: {eval_jac:.4f}")
        self.eval_dice_info.append([self.step, eval_dice])
        self.eval_dice30_info.append([self.step, eval_dice30])
        self.eval_hd95_info.append([self.step, eval_hd95])
        self.eval_jaccard_info.append([self.step, eval_jac])
        utils.logger.save_dice(np.array(self.eval_dice_info), filename=self.config.saving_dir)
        utils.logger.save_dice30(np.array(self.eval_dice30_info), filename=self.config.saving_dir)
        utils.logger.save_hd95(np.array(self.eval_hd95_info), filename=self.config.saving_dir)
        utils.logger.save_jaccard(np.array(self.eval_jaccard_info), filename=self.config.saving_dir)


if __name__ == "__main__":
    main()
