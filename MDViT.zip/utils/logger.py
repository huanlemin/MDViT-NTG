import os
import torchvision.utils as tvu
import matplotlib.pyplot as plt
import cv2 as cv
import numpy as np
import torch
from matplotlib.backends.backend_agg import FigureCanvasAgg
from copy import deepcopy
import imageio
import datetime
import argparse
import nibabel as nib


def log_print(message):
    print(datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S] "), message)


def dict2namespace(config):
    namespace = argparse.Namespace()
    for key, value in config.items():
        if isinstance(value, dict):
            new_value = dict2namespace(value)
        else:
            new_value = value
        setattr(namespace, key, new_value)
    return namespace


def namespace2dict(c):
    c_dict = vars(c)
    for key, value in c_dict.items():
        if isinstance(value, argparse.Namespace):
            new_value = namespace2dict(value)
        else:
            new_value = value
        c_dict[key] = new_value
    return c_dict

def hum_convert(value):
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    size = 1024.0
    for i in range(len(units)):
        if (value / size) < 1:
            return "%.2f%s" % (value, units[i])
        value = value / size


def save_image(fix_img, move_img, file_directory):
    if not os.path.exists(os.path.dirname(file_directory)):
        os.makedirs(os.path.dirname(file_directory))
    target_slice = int(fix_img.shape[0] / 2)
    fix_img = fix_img[target_slice, :, :]
    move_img = move_img[target_slice, :, :]
    img = torch.cat((fix_img, move_img), dim=1)
    tvu.save_image(img, file_directory)


def save_image_y(fix_img, move_img, file_directory):
    if not os.path.exists(os.path.dirname(file_directory)):
        os.makedirs(os.path.dirname(file_directory))
    target_slice = int(fix_img.shape[0] / 2)
    fix_img = fix_img[:, target_slice, :]
    move_img = move_img[:, target_slice, :]
    img = torch.cat((fix_img, move_img), dim=1)
    tvu.save_image(img, file_directory)


def save_image_z(fix_img, move_img, file_directory):
    if not os.path.exists(os.path.dirname(file_directory)):
        os.makedirs(os.path.dirname(file_directory))
    target_slice = int(fix_img.shape[0] / 2)
    fix_img = fix_img[:, :, target_slice]
    move_img = move_img[:, :, target_slice]
    img = torch.cat((fix_img, move_img), dim=1)
    tvu.save_image(img, file_directory)


def save_nii(array, path):
    array = array.astype(np.float64)
    nifti_image = nib.Nifti1Image(array, affine=np.eye(4))
    nib.save(nifti_image, path)


def save_checkpoint(state, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    torch.save(state,
               os.path.join(filename, 'epoch_' + str(state['epoch']) + '_steps_' + str(state['step']) + '.pth.tar'))


def load_checkpoint(path, device):
    if device is None:
        return torch.load(path)
    else:
        return torch.load(path, map_location=device)


def remove_module_prefix(state_dict):
    new_state_dict = {}
    for k, v in state_dict.items():
        new_key = k.replace("module.", "") if k.startswith("module.") else k
        new_state_dict[new_key] = v
    return new_state_dict


def save_partial_loss(train_loss_info, val_loss_info, filename, ratio=0.8):
    log_size = int(min(val_loss_info.shape[0], train_loss_info.shape[0]) * ratio)
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(train_loss_info[:, 0][log_size:], train_loss_info[:, 1][log_size:], label='train',
             color='royalblue')  # draw train loss
    if val_loss_info.shape[0] != 0:
        plt.plot(val_loss_info[:, 0][log_size:], val_loss_info[:, 1][log_size:], label='val',
                 color='orangered')  # draw val loss
    plt.legend()
    plt.xlabel('steps')
    plt.ylabel('train|val loss')
    plt.savefig(os.path.join(filename, 'train_val_loss_partial.png'))
    plt.cla()
    """ saving another val loss information """
    if val_loss_info.shape[0] != 0:
        plt.plot(val_loss_info[:, 0][log_size:], val_loss_info[:, 1][log_size:], color='orangered')  # draw val loss
    plt.xlabel('steps')
    plt.ylabel('val loss')
    plt.savefig(os.path.join(filename, 'val_loss_partial.png'))
    plt.cla()


def save_loss(train_loss_info, val_loss_info, filename, step, partial_iters=10000):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(train_loss_info[:, 0], train_loss_info[:, 1], label='train', color='royalblue')  # draw train loss
    if val_loss_info.shape[0] != 0:
        plt.plot(val_loss_info[:, 0], val_loss_info[:, 1], label='val', color='orangered')  # draw val loss
    plt.legend()
    plt.xlabel('steps')
    plt.ylabel('train|val loss')
    plt.savefig(os.path.join(filename, 'train_val_loss.png'))
    plt.cla()
    """ saving another val loss information """
    if val_loss_info.shape[0] != 0:
        plt.plot(val_loss_info[:, 0], val_loss_info[:, 1], color='orangered')  # draw val loss
    plt.xlabel('steps')
    plt.ylabel('val loss')
    plt.savefig(os.path.join(filename, 'val_loss.png'))
    plt.cla()

    if step > partial_iters:
        save_partial_loss(train_loss_info, val_loss_info, filename)


def save_dice(dice_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(dice_info[:, 0], dice_info[:, 1], color='darkgreen')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('dice (average of val samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'dice.png'))
    plt.cla()


def save_hd95(hd95_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(hd95_info[:, 0], hd95_info[:, 1], color='purple')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('hd95 (average of val samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'HD95.png'))
    plt.cla()


def save_jaccard(jac_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(jac_info[:, 0], jac_info[:, 1], color='darkorange')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('Jaccard (average of val samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'jaccard.png'))
    plt.cla()


def save_dice30(dice30_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(dice30_info[:, 0], dice30_info[:, 1], color='darkorange')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('dice30 (average of val samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'dice30.png'))
    plt.cla()


def save_dice_tr(dice_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(dice_info[:, 0], dice_info[:, 1], color='darkgreen')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('dice (average of train samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'dice_tr.png'))
    plt.cla()


def save_hd95_tr(hd95_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(hd95_info[:, 0], hd95_info[:, 1], color='purple')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('hd95 (average of train samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'HD95_tr.png'))
    plt.cla()


def save_jaccard_tr(jac_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(jac_info[:, 0], jac_info[:, 1], color='darkorange')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('Jaccard (average of train samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'jaccard_tr.png'))
    plt.cla()


def save_dice30_tr(dice30_info, filename):
    if not os.path.exists(filename):
        os.makedirs(filename)
    plt.plot(dice30_info[:, 0], dice30_info[:, 1], color='darkorange')  # draw train loss
    plt.xlabel('steps')
    plt.ylabel('dice30 (average of train samples)')
    plt.grid(color='gainsboro')
    plt.savefig(os.path.join(filename, 'dice30_tr.png'))
    plt.cla()
