import torch.optim as optim

def get_optimizer(config, parameters):
    if config.optim.optimizer == 'Adam':
        return optim.Adam(filter(lambda p: p.requires_grad, parameters), lr=config.optim.lr, weight_decay=config.optim.weight_decay,
                          betas=(0.9, 0.999), amsgrad=config.optim.amsgrad, eps=config.optim.eps)
    elif config.optim.optimizer == 'RMSProp':
        return optim.RMSprop(filter(lambda p: p.requires_grad, parameters), lr=config.optim.lr, weight_decay=config.optim.weight_decay)
    elif config.optim.optimizer == 'SGD':
        return optim.SGD(filter(lambda p: p.requires_grad, parameters), lr=config.optim.lr, momentum=0.9)
    else:
        raise NotImplementedError('Optimizer {} not understood.'.format(config.optim.optimizer))

def get_optimizer_scheduler(optimizer, step_size, gamma):
    """
    Generating Optimizer scheduler.
    decrease optimizer learning rate when steps are increasing.
    Need "scgeduler.step()" at the end of one epoch
    :param optimizer: network optimizer
    :param step_size: Period of learning rate decay, can see in config
    :param gamma:Multiplicative factor of learning rate decay, can see in config
    :return: scheduler
    More detail: https://pytorch.org/docs/stable/generated/torch.optim.lr_scheduler.StepLR.html#torch.optim.lr_scheduler.StepLR
    """
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=gamma)
    return scheduler